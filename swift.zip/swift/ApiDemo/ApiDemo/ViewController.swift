//
//  ViewController.swift
//  ApiDemo
//
//  Created by Leslie Helou on 8/16/17.
//  Copyright © 2017 jamf. All rights reserved.
//

import Cocoa
import WebKit

class ViewController: NSViewController, URLSessionDelegate {

    @IBOutlet weak var jamfServer_TextField: NSTextField!
    @IBOutlet weak var uname_TextField: NSTextField!
    @IBOutlet weak var passwd_TextField: NSSecureTextField!
    
    @IBOutlet weak var results_ScrollView: NSScrollView!
    @IBOutlet var results_TextView: NSTextView!
    
    var displayResults = ""

    @IBAction func get(_ sender: Any) {
        self.results_TextView.string = ""
        apiCall(endpoint: "computers") {
            (result: String) in
            self.results_TextView.string = "\(result)"
        }
    
    }
    
    @IBAction func QuitNow(sender: AnyObject) {
        NSApplication.shared().terminate(self)
    }
    
    func apiCall(endpoint: String, completion: @escaping (_ result: String) -> Void) {
        URLCache.shared.removeAllCachedResponses()
        let safeCharSet = CharacterSet.alphanumerics
        
        let username = uname_TextField.stringValue.addingPercentEncoding(withAllowedCharacters: safeCharSet)
        let password = passwd_TextField.stringValue.addingPercentEncoding(withAllowedCharacters: safeCharSet)
        let jamfCreds = "\(username ?? ""):\(password ?? "")"

        let jamfUtf8Creds = jamfCreds.data(using: String.Encoding.utf8)
        let jamfBase64Creds = (jamfUtf8Creds?.base64EncodedString())!
    
        let endpointUrl = jamfServer_TextField.stringValue
        
        let encodedURL = NSURL(string: endpointUrl)
        let request = NSMutableURLRequest(url: encodedURL! as URL)
    
        request.httpMethod = "GET"
        let serverConf = URLSessionConfiguration.default
        serverConf.httpAdditionalHeaders = ["Authorization" : "Basic \(jamfBase64Creds)", "Content-Type" : "application/json", "Accept" : "application/json"]
        let serverSession = Foundation.URLSession(configuration: serverConf, delegate: self, delegateQueue: OperationQueue.main)
        let task = serverSession.dataTask(with: request as URLRequest, completionHandler: {
            (data, response, error) -> Void in
            if let httpResponse = response as? HTTPURLResponse {
                do {
                    let json = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments)
                    if let endpointJSON = json as? [String: Any] {
                        if let endpointInfo = endpointJSON[endpoint] as? [Any] {
                            for i in (0..<endpointInfo.count) {
                                let theRecord = endpointInfo[i] as! [String : AnyObject]
                                let recordId = theRecord["id"] as! Int
                                let recordName = theRecord["name"] as! String
                                self.displayResults.append("ID: \(recordId)\t Name: \(recordName)\n")
                            }
                        } else {
                            print("if let endpointInfo = endpointJSON['\(endpoint)'] error.)\n")
                        }
                    }  else {  // if let serverEndpointJSON - end
                        print("existing endpoints: error serializing JSON: \(String(describing: error))\n")
                    }
                }   // end do
                if httpResponse.statusCode >= 199 && httpResponse.statusCode <= 299 {
                    completion(self.displayResults)
                } else {
                    // something went wrong
                    print("status code: \(httpResponse.statusCode)")
                    completion(self.displayResults)
                }   // if httpResponse.statusCode - end
            }   // if let httpResponse = response - end
        })   // let task = serverSession.dataTask - end
        task.resume()
    }   // func apiCall - end
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    // needed, along with Info.plist changes, to connect to servers using untrusted certificates
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping(  URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        completionHandler(.useCredential, URLCredential(trust: challenge.protectionSpace.serverTrust!))
    }

}

